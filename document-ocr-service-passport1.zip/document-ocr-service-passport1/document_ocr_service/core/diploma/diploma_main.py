from urllib.parse import urljoin

import asyncio
from pydantic import ValidationError

from ..ocr import ocr_predictor, DocumentFile
from ..text_similarity import TextSimilarity
from ..image_convert import convert_hex_image_str_to_bytes_stream
from .diploma_struct import EducationType, DiplomaStructure
from ..settings import settings
from ..datamodel import UniversityFullNameOCR, University, SpecialityNameOCR, Speciality, SpecialistProfessionOCR, SpecialistProfession
from ..async_client import fetch_all

class TextSimilarityDiplomaMain(TextSimilarity):
    """

    """
    def __init__(self):
        TextSimilarity.__init__(self, 0.9)
        self.known_strings = {
            "title": "РОССИЙСКАЯ ФЕДЕРАЦИЯ",
            "name": "Настоящий диплом свидетельствует о том, что",
            "specialty_bachelor": "освоил(а) программу бакалавриата по направлению подготовки",
            "specialty_master": "освоил(а) программу магистратуры по направлению подготовки",
            "specialty_specialist": "освоил(а) программу специалитета по специальности",
            "specialty_last": "и успешно прошел(ла) государственную итоговую атестацию",
            "qualification_1": "Решением Государственной экзаменационной комиссии",
            "qualification_2": "присвоена квалификация",
            "number": "ДОКУМЕНТ ОБ ОБРАЗОВАНИИ И О КВАЛИФИКАЦИИ",
            "reg_number": "Регистрационный номер",
            "date": "Дата выдачи"
        }

    def identify_known_string(self, lines: list) -> dict:
        """

        :param lines:
        :return:
        """
        idetifed_string_indexes = {}
        i = 0
        spec_sim = 0
        spec_name = ""
        spec_index = 0

        for line in lines:

            cur_str = TextSimilarity.get_text_line(line)

            for key, known_str in self.known_strings.items():
                sim = TextSimilarity.similarity(cur_str, known_str)
                # костыль для определения типа образования одного из трех
                if key in ['specialty_bachelor', 'specialty_master', 'specialty_specialist']:
                    if sim > spec_sim:
                        spec_sim = sim
                        spec_name = key
                        spec_index = i
                    if key == 'specialty_specialist':
                        if spec_sim > self.threshold_similarity:
                            idetifed_string_indexes[spec_name] = spec_index
                    continue

                if sim > self.threshold_similarity:
                    idetifed_string_indexes[key] = i
            i += 1
        return idetifed_string_indexes


def ocr_analyze_diploma_main_image(image_hex: str) -> dict:
    """
    Получение текстовых данных из картинки диплома при помощи OCR
    :param image:
    :return:
    """

    request_dict = {}

    imgByteArr = convert_hex_image_str_to_bytes_stream(image_hex)


    model = ocr_predictor(pretrained=True, lang="rus")
    # #
    doc = DocumentFile.from_images(imgByteArr.getvalue())
    # # Analyze
    result = model(doc)
    result = result.export()

    text_sim_obj = TextSimilarityDiplomaMain()

    pages = result['pages']

    # разбиение на 2 страницы
    left_lines = []
    right_lines = []
    for page in pages:
        blocks = page['blocks']
        for block in blocks:
            for line in block['lines']:
                if block['geometry'][1][0] > 0.5:
                    right_lines.append(line)
                else:
                    left_lines.append(line)

    diploma_data = DiplomaStructure()

    # распознование левой части диплома
    res_left_lines = text_sim_obj.identify_known_string(left_lines)
    index_university = 1
    if res_left_lines.get("title"):
        index_university = res_left_lines.get("title") + 1
    if res_left_lines.get("number"):
        index = res_left_lines.get("number")
        num_index = index - 1
        num_line = left_lines[num_index]
        diploma_data.number = text_sim_obj.get_text_line(num_line)


        # ПЕРЕНЕСТИ в распознование по ключу
        type_index = index - 2
        if text_sim_obj.is_almost_equal(text_sim_obj.get_text_line(left_lines[type_index]), "С ОТЛИЧИЕМ"):
            diploma_data.with_honor = True


        type_index_first = index - 2 - int(diploma_data.with_honor)
        if text_sim_obj.is_almost_equal(text_sim_obj.get_text_line(left_lines[type_index_first]), "ДИПЛОМ"):
            if text_sim_obj.is_almost_equal(text_sim_obj.get_text_line(left_lines[type_index_first + 1]), "БАКАЛАВРА"):
                diploma_data.type_of_education = EducationType.Bakalavriat
            elif text_sim_obj.is_almost_equal(text_sim_obj.get_text_line(left_lines[type_index_first + 1]), "МАГИСТРА"):
                diploma_data.type_of_education = EducationType.Magistratura
            elif text_sim_obj.is_almost_equal(text_sim_obj.get_text_line(left_lines[type_index_first + 1]), "СПЕЦИАЛИСТА"):
                diploma_data.type_of_education = EducationType.Spetsialitet

        university_name = ""
        for i in range(index_university, type_index_first):
            line_text = text_sim_obj.get_text_line(left_lines[i])
            if not text_sim_obj.is_almost_equal(line_text, "ДУБЛИКАТ"):
                university_name += line_text + " "
        diploma_data.university = university_name

        # подготовка запроса
        un_full_name = UniversityFullNameOCR(full_name=university_name)
        url_full_name_ocr = urljoin(settings.guide_app_url, "guide/university_full_name_ocr")
        request_dict[url_full_name_ocr] = un_full_name

    if res_left_lines.get("reg_number"):
        index = res_left_lines.get("reg_number")
        reg_number_index = index + 1
        reg_number_line = left_lines[reg_number_index]
        diploma_data.reg_number = text_sim_obj.get_text_line(reg_number_line)
    elif res_left_lines.get("number"):
        index = res_left_lines.get("number")
        reg_number_index = index + 2
        reg_number_line = left_lines[reg_number_index]
        diploma_data.reg_number = text_sim_obj.get_text_line(reg_number_line)
    if res_left_lines.get("date"):
        index = res_left_lines.get("date")
        date_index = index + 1
        date_line = left_lines[date_index]
        diploma_data.date = text_sim_obj.get_text_line(date_line)
    elif res_left_lines.get("number"):
        index = res_left_lines.get("number")
        date_index = index + 4
        date_line = left_lines[date_index]
        diploma_data.date = text_sim_obj.get_text_line(date_line)

    # распознование правой части диплома
    if right_lines:
        res_right_lines = text_sim_obj.identify_known_string(right_lines)

        index_name_first = res_right_lines.get("name", 0) + 1
        index_specialty = 3
        if "specialty_bachelor" in res_right_lines.keys():
            index_specialty = res_right_lines["specialty_bachelor"]
            diploma_data.type_of_education = EducationType.Bakalavriat
        elif "specialty_master" in res_right_lines.keys():
            index_specialty = res_right_lines["specialty_master"]
            diploma_data.type_of_education = EducationType.Magistratura
        elif "specialty_specialist" in res_right_lines.keys():
            index_specialty = res_right_lines["specialty_specialist"]
            diploma_data.type_of_education = EducationType.Spetsialitet
        index_name_last = index_specialty - 1
        full_name_text = text_sim_obj.get_text_line(right_lines[index_name_first]) + \
                                                     " " + \
                                                     text_sim_obj.get_text_line(right_lines[index_name_last])
        full_name_list = full_name_text.split()
        try:
            diploma_data.last_name = full_name_list[0]
        except IndexError:
            pass
        try:
            diploma_data.first_name = full_name_list[1]
        except IndexError:
            pass
        try:
            diploma_data.patronymic = full_name_list[2]
        except IndexError:
            pass

        index_specialty_last = res_right_lines.get("specialty_last")
        if index_specialty_last:
            specialty_lines = right_lines[index_specialty+1:index_specialty_last]
            full_specialty_text = ""
            for line in specialty_lines:
                full_specialty_text += text_sim_obj.get_text_line(line) + " "

            specialty_words = full_specialty_text.split()
            specialty_code = specialty_words[0]
            diploma_data.specialty_code = specialty_code
            diploma_data.specialty = " ".join(specialty_words[1:])

            # подготовка запроса
            spec_name = SpecialityNameOCR(name=diploma_data.specialty, education_type=diploma_data.type_of_education)
            url_spec_name_ocr = urljoin(settings.guide_app_url, "guide/speciality_name_ocr")
            request_dict[url_spec_name_ocr] = spec_name

        if res_right_lines.get("qualification_1"):
            if res_right_lines.get("qualification_2"):
                index_qualification = res_right_lines.get("qualification_2") + 1
                qualification_line = right_lines[index_qualification]
                diploma_data.profession = text_sim_obj.get_text_line(qualification_line)
            else:
                index_qualification = res_right_lines.get("qualification_1") + 2
                qualification_line = right_lines[index_qualification]
                diploma_data.profession = text_sim_obj.get_text_line(qualification_line)
        elif res_right_lines.get("qualification_2"):
            index_qualification = res_right_lines.get("qualification_2") + 1
            qualification_line = right_lines[index_qualification]
            diploma_data.profession = text_sim_obj.get_text_line(qualification_line)

        if text_sim_obj.is_almost_equal(diploma_data.profession, "Магистр"):
            diploma_data.type_of_education = EducationType.Magistratura
            diploma_data.profession = "Магистр"
        elif text_sim_obj.is_almost_equal(diploma_data.profession, "Бакалавр"):
            diploma_data.type_of_education = EducationType.Bakalavriat
            diploma_data.profession = "Бакалавр"

    loop = asyncio.new_event_loop()
    responces = loop.run_until_complete(fetch_all(request_dict, loop))

    for responce in responces:
        try:
            if responce[0] == url_full_name_ocr:
                res = responce[1]
                un_obj = University(**res)
                diploma_data.university = un_obj.full_name
            elif responce[0] == url_spec_name_ocr:
                res = responce[1]
                spec_obj = Speciality(**res)
                diploma_data.specialty = spec_obj.name
                diploma_data.specialty_code = spec_obj.code
        except ValidationError as e:
            print(e)

    if diploma_data.specialty_code and diploma_data.type_of_education == EducationType.Spetsialitet:
        spec_prof = SpecialistProfessionOCR(profession=diploma_data.profession, code=diploma_data.specialty_code)
        url_spec_prof_ocr = urljoin(settings.guide_app_url, "guide/get_specialist_profession_by_ocr_name")
        loop = asyncio.new_event_loop()
        responces = loop.run_until_complete(fetch_all({url_spec_prof_ocr: spec_prof}, loop))
        try:
            responce = responces[0]
            res = responce[1]
            prof_obj = SpecialistProfession(**res)
            diploma_data.profession = prof_obj.profession
        except ValidationError as e:
            print(e)

    return diploma_data.dict()

