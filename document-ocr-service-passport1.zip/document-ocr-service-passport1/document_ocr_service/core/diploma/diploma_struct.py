from pydantic import BaseModel
from ..datamodel import EducationType


class DiplomaStructure(BaseModel):
    university: str = ""
    type_of_education: EducationType = EducationType.Bakalavriat
    with_honor: bool = False
    number: str = ""
    reg_number: str = ""
    date: str = ""
    last_name: str = ""
    first_name: str = ""
    patronymic: str = ""
    specialty_code: str = ""
    specialty: str = ""
    profession: str = ""
