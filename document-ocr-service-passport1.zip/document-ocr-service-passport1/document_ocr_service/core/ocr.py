from multiprocessing import Process, Manager

from doctr.io import DocumentFile
from doctr.models import ocr_predictor

# from PIL import Image, ImageEnhance, ImageFilter
# from matplotlib import cm
import cv2
from doctr.models.detection.zoo import detection_predictor
from doctr.models.recognition.zoo import recognition_predictor

import pytesseract
from paddleocr import PaddleOCR

from doctr.models._utils import estimate_orientation
from doctr.models.builder import DocumentBuilder
from doctr.models.detection.predictor import DetectionPredictor
from doctr.models.recognition.predictor import RecognitionPredictor
from doctr.utils.geometry import rotate_boxes, rotate_image
from doctr.utils.repr import NestedObject

from doctr.models.classification import crop_orientation_predictor
from doctr.models.predictor.base import _OCRPredictor


from typing import Any, List, Tuple, Union

import numpy as np
import tensorflow as tf

from doctr.models.preprocessor import PreProcessor
from doctr.utils.repr import NestedObject



def ocr_list_images_by_paddle(images_list, result):
    """
    Распознование текста с массива изображений используя PaddleOCR
    :param images_list: массив изображений
    :param result: словарь multiprocessing.Manager.dict() в который записывается результат распознования
    :return:
    """
    ocr = PaddleOCR(lang="ru")  # The model file will be downloaded automatically when executed for the first time
    word_preds = ocr.ocr([crop for page_crops in images_list for crop in page_crops],  det=False)
    result["result"] = word_preds


class OCRPredictor(NestedObject, _OCRPredictor):
    """Implements an object able to localize and identify text elements in a set of documents

    Args:
        det_predictor: detection module
        reco_predictor: recognition module
        assume_straight_pages: if True, speeds up the inference by assuming you only pass straight pages
            without rotated textual elements.
        export_as_straight_boxes: when assume_straight_pages is set to False, export final predictions
            (potentially rotated) as straight bounding boxes.
        straighten_pages: if True, estimates the page general orientation based on the median line orientation.
            Then, rotates page before passing it to the deep learning modules. The final predictions will be remapped
            accordingly. Doing so will improve performances for documents with page-uniform rotations.
    """
    _children_names = ['det_predictor', 'reco_predictor']

    def __init__(
        self,
        det_predictor: DetectionPredictor,
        reco_predictor: RecognitionPredictor,
        assume_straight_pages: bool = True,
        export_as_straight_boxes: bool = False,
        straighten_pages: bool = False,
        lang: str = "rus+eng"
    ) -> None:

        super().__init__()
        self.det_predictor = det_predictor
        self.reco_predictor = reco_predictor
        self.doc_builder = DocumentBuilder(export_as_straight_boxes=export_as_straight_boxes)
        self.assume_straight_pages = assume_straight_pages
        self.straighten_pages = straighten_pages
        self.crop_orientation_predictor = crop_orientation_predictor(pretrained=True)
        self.lang = lang

    def __call__(
        self,
        pages: List[Union[np.ndarray, tf.Tensor]],
        **kwargs: Any,
    # ) -> Document:
    ):
        # Dimension check
        if any(page.ndim != 3 for page in pages):
            raise ValueError("incorrect input shape: all pages are expected to be multi-channel 2D images.")

        origin_page_shapes = [page.shape[:2] for page in pages]

        # Detect document rotation and rotate pages
        if self.straighten_pages:
            origin_page_orientations = [estimate_orientation(page) for page in pages]
            pages = [rotate_image(page, -angle, expand=True) for page, angle in zip(pages, origin_page_orientations)]

        # Localize text elements
        loc_preds = self.det_predictor(pages, **kwargs)
        # Crop images
        crops, loc_preds = self._prepare_crops(
            pages, loc_preds, channels_last=True, assume_straight_pages=self.assume_straight_pages
        )
        # Rectify crop orientation
        if not self.assume_straight_pages:
            crops, loc_preds = self._rectify_crops(crops, loc_preds)

        # Identify character sequences
        # OLD word_preds = self.reco_predictor([crop for page_crops in crops for crop in page_crops], **kwargs)

        #paddle ocr
        multiprocessing_manager = Manager()
        result_dict_ocr_paddle = multiprocessing_manager.dict()
        proc_paddle_ocr = Process(target=ocr_list_images_by_paddle, args=(crops, result_dict_ocr_paddle))
        proc_paddle_ocr.start()

        word_preds = []
        #tesseract
        for img_cv in [crop for page_crops in crops for crop in page_crops]:
            img_cv = cv2.cvtColor(img_cv, cv2.COLOR_BGR2RGB)
            # DEBUG ############################ показ картинки на экране
            # cv2.imshow('Example - Show image in window', img_cv)
            # cv2.waitKey(0)  # waits until a key is pressed

            # # ################################## преобразование в чб
            # img_cv = Image.fromarray(np.uint8(img_cv)).convert('RGB')
            # enhancer = ImageEnhance.Contrast(img_cv)
            # img_cv = enhancer.enhance(2)
            # # Преобразуем в черно-белый рисунок:
            # thresh = 200
            # fn = lambda x: 255 if x > thresh else 0
            # img_cv = img_cv.convert('L').point(fn, mode='1')
            # # ################################## преобразование в чб
            # img_cv.save(f"res/{i}.png")

            # Up-sample
            # img = cv2.resize(img_cv, (0, 0), fx=2, fy=2)
            # # Convert to the gray-scale
            # gry = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
            # # Simple-threshold
            # thr = cv2.threshold(gry, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)[1]

            res = pytesseract.image_to_string(img_cv, lang=self.lang, config="--psm 6 --oem 3")

            res = res.replace("\n", "")
            res = res.replace("\x0c", "")

            word_preds.append( (res, 0.9) )
            # print(res)
            # Also switch the language by modifying the lang parameter

        #paddle
        proc_paddle_ocr.join()
        word_preds_paddle = result_dict_ocr_paddle["result"]
        for i in range(len(word_preds_paddle)):
            if word_preds[i][0] == "":
                word_preds[i] = word_preds_paddle[i]
            elif word_preds_paddle[i][1] >= 0.99:
                word_preds[i] = word_preds_paddle[i]


        boxes, text_preds = self._process_predictions(loc_preds, word_preds)

        # Rotate back pages and boxes while keeping original image size
        if self.straighten_pages:
            boxes = [rotate_boxes(page_boxes, angle, orig_shape=page.shape[:2]) for
                     page_boxes, page, angle in zip(boxes, pages, origin_page_orientations)]

        out = self.doc_builder(boxes, text_preds, origin_page_shapes)  # type: ignore[misc]
        return out


def _predictor(
    det_arch: str,
    reco_arch: str,
    pretrained: bool,
    assume_straight_pages: bool = True,
    preserve_aspect_ratio: bool = False,
    det_bs: int = 2,
    reco_bs: int = 128,
    **kwargs,
) -> OCRPredictor:

    # Detection
    det_predictor = detection_predictor(
        det_arch,
        pretrained=pretrained,
        batch_size=det_bs,
        assume_straight_pages=assume_straight_pages,
        preserve_aspect_ratio=preserve_aspect_ratio,
    )

    # Recognition
    reco_predictor = recognition_predictor(reco_arch, pretrained=pretrained, batch_size=reco_bs)

    return OCRPredictor(
        det_predictor,
        reco_predictor,
        assume_straight_pages=assume_straight_pages,
        **kwargs
    )


def ocr_predictor(
    det_arch: str = 'db_resnet50',
    reco_arch: str = 'crnn_vgg16_bn',
    pretrained: bool = False,
    assume_straight_pages: bool = True,
    export_as_straight_boxes: bool = False,
    preserve_aspect_ratio: bool = False,
    **kwargs: Any
) -> OCRPredictor:
    """End-to-end OCR architecture using one model for localization, and another for text recognition.

    Example::
        >>> import numpy as np
        >>> from doctr.models import ocr_predictor
        >>> model = ocr_predictor('db_resnet50', 'crnn_vgg16_bn', pretrained=True)
        >>> input_page = (255 * np.random.rand(600, 800, 3)).astype(np.uint8)
        >>> out = model([input_page])

    Args:
        det_arch: name of the detection architecture to use (e.g. 'db_resnet50', 'db_mobilenet_v3_large')
        reco_arch: name of the recognition architecture to use (e.g. 'crnn_vgg16_bn', 'sar_resnet31')
        pretrained: If True, returns a model pre-trained on our OCR dataset
        assume_straight_pages: if True, speeds up the inference by assuming you only pass straight pages
            without rotated textual elements.
        export_as_straight_boxes: when assume_straight_pages is set to False, export final predictions
            (potentially rotated) as straight bounding boxes.
        preserve_aspect_ratio: If True, pad the input document image to preserve the aspect ratio before
            running the detection model on it.

    Returns:
        OCR predictor
    """

    return _predictor(
        det_arch,
        reco_arch,
        pretrained,
        assume_straight_pages=assume_straight_pages,
        export_as_straight_boxes=export_as_straight_boxes,
        preserve_aspect_ratio=preserve_aspect_ratio,
        **kwargs,
    )
