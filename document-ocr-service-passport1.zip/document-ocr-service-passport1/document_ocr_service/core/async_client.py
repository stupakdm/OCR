import asyncio
import aiohttp
from pydantic import BaseModel


async def fetch_post(session: aiohttp.ClientSession, url: str, datamodel: BaseModel) -> tuple[str, dict]:
    async with session.post(url, json=datamodel.dict()) as response:
        res = await response.json()
        return url, res


async def fetch_all(request_dict: dict, loop):
    async with aiohttp.ClientSession(loop=loop) as session:
        results = await asyncio.gather(*[fetch_post(session, url, datamodel) for url, datamodel in request_dict.items()], return_exceptions=True)
        return results
