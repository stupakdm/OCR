import difflib


class TextSimilarity:
    """

    """
    def __init__(self, threshold_similarity):
        self.threshold_similarity = threshold_similarity

    @staticmethod
    def similarity(s1: str, s2: str) -> float:
        normalized1 = s1.lower()
        normalized2 = s2.lower()
        matcher = difflib.SequenceMatcher(None, normalized1, normalized2)
        return matcher.ratio()

    def delete_almost_equal_substring(self, fullstr: str, substr: str) -> str:
        word_list_substr = substr.split()
        word_list_fullstr = fullstr.split()
        if len(word_list_fullstr) < len(word_list_substr):
            raise Exception("fullstr < substr" )
        for i in range(len(word_list_fullstr)-len(word_list_substr)):
            tmp_fullstr = " ".join(word_list_fullstr[i:(i+len(word_list_substr))])
            tmp_substr = " ".join(word_list_substr)
            if self.is_almost_equal(tmp_fullstr, tmp_substr):
                res_word_list_fullstr = word_list_fullstr[:i] + word_list_fullstr[i+len(word_list_substr):]
                return " ".join(res_word_list_fullstr)
        return fullstr

    def is_almost_equal(self, str1: str, str2: str) -> bool:
        """

        :param str1:
        :param str2:
        :return:
        """
        return TextSimilarity.similarity(str1, str2) > self.threshold_similarity

    @staticmethod
    def get_text_line(line) -> str:
        """

        :param line:
        :return:
        """
        cur_str = ""
        for word_index in range(len(line['words'])):
            cur_str += line['words'][word_index]['value']
            if word_index != len(line['words']) - 1:
                cur_str += " "
        return cur_str
