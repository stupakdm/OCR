from pydantic import BaseModel


class PassportStructure(BaseModel):
    second_name: str = ""
    first_name: str = ""
    patronymic: str = ""
    series: str = ""
    number: str = ""
    birth_date: str = ""
    sex: str = ""
    issue_date: str = ""
    fms_code: str = ""
    fms_name: str = ""
    birth_place: str = ""
