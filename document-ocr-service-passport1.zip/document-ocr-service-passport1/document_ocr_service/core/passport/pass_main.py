from urllib.parse import urljoin
import asyncio
from pydantic import ValidationError
from passporteye import read_mrz
from ..image_convert import convert_hex_image_str_to_bytes_stream
from .pass_struct import PassportStructure
from ..datamodel import DivisionFMSCode, DivisionFMS
from ..settings import settings
from ..async_client import fetch_all

def convert_from_alphabet_code_to_rus(text):
    alphabet = {
    "A": "А",
    "B": "Б",
    "V": "В",
    "G": "Г",
    "D": "Д",
    "E": "Е",
    "2": "Е",
    "J": "Ж",
    "Z": "З",
    "I": "И",
    "Q": "Й",
    "K": "К",
    "L": "Л",
    "M": "М",
    "N": "Н",
    "O": "О",
    "P": "П",
    "R": "Р",
    "S": "С",
    "T": "Т",
    "U": "У",
    "F": "Ф",
    "H": "Х",
    "C": "Ц",
    "3": "Ч",
    "4": "Ш",
    "W": "Щ",
    "X": "Ъ",
    "Y": "Ы",
    "9": "Ь",
    "6": "Э",
    "7": "Ю",
    "8": "Я",
    }
    rus_text = ""
    for item in text:
        rus_text += alphabet.get(item, item)
    return rus_text


def mrz_analyze_passport_image(image_hex: str) -> dict:
    imgByteArr = convert_hex_image_str_to_bytes_stream(image_hex)

    mrz = read_mrz(imgByteArr)

    second_name = mrz.surname
    name_list = mrz.names.split()
    try:
        first_name = name_list[0]
    except IndexError:
        first_name = ""
    try:
        patronymic = name_list[1]
    except IndexError:
        patronymic = ""
    second_name = convert_from_alphabet_code_to_rus(second_name)
    first_name = convert_from_alphabet_code_to_rus(first_name)
    patronymic = convert_from_alphabet_code_to_rus(patronymic)

    series = mrz.number[:3] + mrz.personal_number[0]
    number = mrz.number[3:]

    birth_day = mrz.date_of_birth[4:6]
    if not birth_day:
        birth_day = "00"
    birth_month = mrz.date_of_birth[2:4]
    if not birth_month:
        birth_month = "00"
    birth_year_short = mrz.date_of_birth[0:2]
    if int(birth_year_short) > 50:
        birth_year = "19" + birth_year_short
    else:
        birth_year = "20" + birth_year_short

    sex = mrz.sex

    issue_date_day = mrz.personal_number[5:7]
    issue_date_month = mrz.personal_number[3:5]
    issue_date_year = "20" + mrz.personal_number[1:3]

    fms_code = mrz.personal_number[7:10] + "-" + mrz.personal_number[10:13]

    fms_name = ""
    try:
        spec_prof = DivisionFMSCode(code=fms_code)
        url_spec_prof_ocr = urljoin(settings.guide_app_url, "guide/fms_code")
        loop = asyncio.new_event_loop()
        responces = loop.run_until_complete(fetch_all({url_spec_prof_ocr: spec_prof}, loop))
        responce = responces[0]
        res = responce[1]
        if res:
            # TODO сейчас fms_name берется случайным образом так как одному коду могут соответствовать несколько описаний
            div_obj = DivisionFMS(**res[-1])
            fms_name = div_obj.description
    except ValidationError as e:
        print(e)

    #TODO место рождения пока пустое потому что не указывается в mrz

    pass_struct = PassportStructure()
    pass_struct.second_name = second_name
    pass_struct.first_name = first_name
    pass_struct.patronymic = patronymic
    pass_struct.sex = sex
    pass_struct.birth_date = birth_day + "." + birth_month + "." + birth_year
    pass_struct.series = series
    pass_struct.number = number
    pass_struct.issue_date = issue_date_day + "." + issue_date_month + "." + issue_date_year
    pass_struct.fms_code = fms_code
    pass_struct.fms_name = fms_name

    return pass_struct.dict()
