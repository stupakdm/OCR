from pydantic import BaseSettings, AnyUrl


class Settings(BaseSettings):

    guide_app_url: AnyUrl = "http://192.168.0.54:8000"


settings = Settings()