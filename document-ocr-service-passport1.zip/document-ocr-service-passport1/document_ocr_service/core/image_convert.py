from PIL import Image
from io import BytesIO


def convert_hex_image_str_to_bytes_stream(hex_image: str) -> BytesIO:
    """
    Конвертирование картинки представленной в виде hex в BytesIO
    :param hex_image:
    :return:
    """
    image = bytes.fromhex(hex_image)
    image = Image.open(BytesIO(image))
    # converting to jpg
    image = image.convert("RGB")
    img_byte_arr = BytesIO()
    image.save(img_byte_arr, format="png")
    return img_byte_arr
