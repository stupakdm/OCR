from .celery import app
from core.diploma.diploma_main import ocr_analyze_diploma_main_image

@app.task
def analyze_diploma_main_image(image: str):
    return ocr_analyze_diploma_main_image(image)
