from .celery import app
from core.passport.pass_main import mrz_analyze_passport_image


@app.task
def analyze_passport_image(image: str):
    return mrz_analyze_passport_image(image)
