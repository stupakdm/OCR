from document_ocr_service.diploma_celery.celery import app as diploma_celery_app

with open("../test_data/5.jpg", "rb") as image:
  f = image.read()
  b = bytes(f)
  b = b.hex()

res = diploma_celery_app.send_task('diploma_celery.tasks.analyze_diploma_main_image', kwargs={'image': b})
res.get(timeout=60)
