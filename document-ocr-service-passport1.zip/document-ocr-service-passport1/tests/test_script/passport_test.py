from document_ocr_service.diploma_celery.celery import app as diploma_celery_app

with open("../test_data/679c9fef4007af9267bda.jpg", "rb") as image:
  f = image.read()
  b = bytes(f)
  b = b.hex()

res = diploma_celery_app.send_task('passport_celery.tasks.analyze_passport_image', kwargs={'image': b})
res.get(timeout=60)
