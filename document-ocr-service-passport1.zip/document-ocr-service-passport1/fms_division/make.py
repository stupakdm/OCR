import csv
from document_ocr_service.core import DivisionFMS, Base
from sqlalchemy.orm import sessionmaker
from sqlalchemy import create_engine

engine = create_engine('postgresql://dbuser:12345678@192.168.2.21:5432/fms_catalog')
# Create all tables by issuing CREATE TABLE commands to the DB.
Base.metadata.create_all(engine)
# Creates a new session to the database by using the engine we described.
Session = sessionmaker(bind=engine)
session = Session()


with open('fms_division/fms_unit.csv') as csv_file:
    csv_reader = csv.reader(csv_file, delimiter=',')
    line_count = 0
    for row in csv_reader:
        if line_count == 0:
            print(f'Column names are {", ".join(row)}')
            line_count += 1
        else:
            line_count += 1

            new_division = DivisionFMS()
            new_division.code = row[0]
            new_division.description = row[1]
            session.add(new_division)
            session.commit()

all_div = session.query(DivisionFMS).count()
print(all_div)
