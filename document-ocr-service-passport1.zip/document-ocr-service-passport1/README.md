# Document OCR Service

Text recognition from documents